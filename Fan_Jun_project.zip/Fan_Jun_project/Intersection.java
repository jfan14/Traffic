package Traffic.RoadNetwork;
import Traffic.RoadNetwork.Block;
/**
 * This class also inherit {@link Block} class, that create intersection block
 * @author junfan
 *
 */
public class Intersection extends Block {
	double turn;
	Block neighbor;
	public Intersection() {
		
	}						
	//constructor
	
	public Intersection(int t, int no, double new_turn) {
		super(t, no);
		this.turn = new_turn;
	}
	
	public Block getNeighbor() {
		return this.neighbor;
	}
	
	public void setNeighbor(Block neighbor) {
		this.neighbor = neighbor;
	}
														//setter and getter
	public double getTurn() {
		return this.turn;
	}
	
	public void setTurn(double turn) {
		this.turn = turn;
	}
	/**
	 * This is the moveForward method, to determine whether it move straight or stay
	 */
	public boolean moveForward() {
		if(this.getNext().getAuto() == null) {//the same as what we have in normal block
			return true;//can move forward
		}else {
			return false;//stay
		}
				
	}
	/**
	 * This is the turning method, it will determined whether it will trun or not
	 * @return
	 */
	public boolean turning() {
		double rndVal = Math.random();//random generator to determine will turn or will go straight
		if(rndVal >= turn && this.getNeighbor().getAuto() == null)
			return true;//return true means turn
		else 
			return false;//return false means go straight
	}
}
