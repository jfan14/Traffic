package Traffic.RoadNetwork;
import Traffic.RoadNetwork.Block;
import Traffic.RoadNetwork.Normal;
import Traffic.RoadNetwork.Intersection;
import Traffic.RoadNetwork.Traffic;
import java.util.*;
/**
 * This is the biggest class of all classes that we have, i created the road network here, there are a lot of methods in this class.
 * @author junfan
 *in the constructor we build the road network which will be the core part of the whole project
 */
public class RoadNetwork{
	private int span;			//the length of the lane before it reaches intersection
	private double entryRate;	//the entry determine whether a car can enter road
	private int totalTicks;		//Total time we want to see it works
	private double turnRate;	//the chance that it turn
	//Create four arraylist for each lane
	ArrayList<Block> NS = new ArrayList<Block>();		//I create four lanes for the road network NS,SN,EW,WE respectively with arraylist
	ArrayList<Block> SN = new ArrayList<Block>();
	ArrayList<Block> EW = new ArrayList<Block>();
	ArrayList<Block> WE = new ArrayList<Block>();
	ArrayList<ArrayList<Block>>lanes = new ArrayList<ArrayList<Block>>();	//now I want to create a arraylist of arraylist, because it is easy to modified one instead of four lanes
	ArrayList<Auto>veh = new ArrayList<Auto>();		//now i created a arraylist of vehicle object
	
	public RoadNetwork(int new_span, int gDuration, int oDuration, double new_entryRate, int new_totalTicks, double new_turnRate) { //Now create the roadNetwork
		this.span = new_span;		//this is the constructor, and in the constructor we will build our road
		this.entryRate = new_entryRate;
		this.totalTicks = new_totalTicks;		
		this.turnRate = new_turnRate;
		lanes.add(NS); //i am adding each lane into the arraylist object lanes
		lanes.add(SN);
		lanes.add(EW);
		lanes.add(WE);
		for(int i=0;i<span-1;i++) {//loop for create span-1 number of normal block four each lane
			NS.add(new Normal(0, i));	//now i am building normal block
			SN.add(new Normal(0, i));	//because from start point, to the last normal block before traffic will be the number of span-1, so limit to span-1
			EW.add(new Normal(0, i));
			WE.add(new Normal(0, i));
		}
		NS.add(new Traffic(2, span-1, gDuration, oDuration, 0));//then every lane has only one traffic block, so no loop needed here for each lane, building traffic.
		SN.add(new Traffic(2, span-1, gDuration, oDuration, 0)); //like combining all pieces to a whole thing 
		EW.add(new Traffic(2, span-1, gDuration, oDuration, 0));//Because the position of traffic block according to the diagram given in pdf is right on the number of span-1
		WE.add(new Traffic(2, span-1, gDuration, oDuration, 0));
		//now adding intersection blocks, because each intersection block overlap twice, so there will be 8 intersection blocks in total, combining intersection pieces to the whole thing
		NS.add(new Intersection(1, span, new_turnRate));		//we know that intersection block from pdf is right on the number of span
		NS.add(new Intersection(1, span + 1, new_turnRate));	
		SN.add(new Intersection(1, span, new_turnRate));
		SN.add(new Intersection(1, span + 1, new_turnRate));
		EW.add(new Intersection(1, span, new_turnRate));
		EW.add(new Intersection(1, span + 1, new_turnRate));
		WE.add(new Intersection(1, span, new_turnRate));
		WE.add(new Intersection(1, span + 1, new_turnRate));
		//After intersection blocks there are more numbers of blocks of span number
		for(int j=span+1;j<2*span+2;j++) {
			NS.add(new Normal(0,j));
			SN.add(new Normal(0,j));
			EW.add(new Normal(0,j)); //then we notice that there are still few normal blocks after intersection block, therefore we do something like what we did earlier but change the range of the loop
			WE.add(new Normal(0,j));
		}
		
		//Setting the next block attribute
		for(int y=0;y<NS.size() - 1;y++) {//so from the diagram, that we know the length of each lane is the same, therefore in the for loop i just use the size of the NS can represent all other lanes length
			NS.get(y).setNext(NS.get(y+1));	
			SN.get(y).setNext(SN.get(y+1));	//it will be useful when we want to check whether next block has car
			WE.get(y).setNext(WE.get(y+1));
			EW.get(y).setNext(EW.get(y+1));
		}
		
		//I want to find the block that can turn to next to the intersection blocks
		((Intersection)SN.get(span)).setNeighbor(WE.get(span + 2));		//from the diagram, we can see that SN's intersection can lead to WE at the first intersection 
		((Intersection)SN.get(span + 1)).setNeighbor(EW.get(span+1));	//or or EW at the second intersection
		((Intersection)NS.get(span)).setNeighbor(EW.get(span + 2));		//from the diagram, we can see that NS's intersection can lead to WE at the first intersection 
		((Intersection)NS.get(span + 1)).setNeighbor(WE.get(span+1));//or or WE at the second intersection
		((Intersection)EW.get(span)).setNeighbor(SN.get(span + 2));//from the diagram, we can see that EW's intersection can lead to WE at the first intersection 
		((Intersection)EW.get(span + 1)).setNeighbor(NS.get(span+1));//or or NS at the second intersection
		((Intersection)WE.get(span)).setNeighbor(NS.get(span + 2));//from the diagram, we can see that WE's intersection can lead to WE at the first intersection 
		((Intersection)WE.get(span + 1)).setNeighbor(SN.get(span+1));//or or SN at the second intersection
	}
	
	public int getSpan() {
		return this.span;
	}
	
	public void setSpan(int span) {
		this.span = span;
	}
	
	public double getEntryRate() {
		return this.entryRate;
	}
	
	public void setEntryRate(double entryRate) {
		this.entryRate = entryRate;
	}
	
	public double getTurnRate() {
		return this.turnRate;
	}
	
	public void setTurnRate(double turnRate) {
		this.turnRate = turnRate;
	}
	/**
	 * this is the method that we spawn cars, and we also want to get the entry time from here
	 * @param entryTime set the entry time
	 */
	public void spawnCars(int entryTime) {		//This is my spawn car method
		double rndVal;	
		int j;
		for(j=0;j<4;j++) {	// 4 is because there are foue lanes, so we can only release four cars at the same time
			ArrayList<Block>lane=lanes.get(j);		//create a new arraylist object and determine the lane get any one of the lane
			rndVal = Math.random();					//random generate number from 0-1
			if (this.entryRate > rndVal) {		//compare if the user's defined entry is bigger than ranVal, release cars or not release cars
				Auto a1 = new Auto();			//I create a auto object
				a1.setEntryTime(entryTime);		//every time there is a car was released i record it entry time, will be useful for calculate from average wait time
				a1.setEntryLane(j);				//will set the lane the vehicle will enter
				lane.get(0).setAuto(a1);	//we release the vehicle at the first block of this lane
				//System.out.println("ggggggggggggggggggg"); a test case when i want to check this method work
			}
		}
	}
	/**
	 * this method is a very important method because it determine whether cars move and how they move
	 * @return return the output
	 */
	public String run() {		//this is the run method, we are moving the vehicles
		double counterNS=0;		//counter for each lane is for check how many cars during the total has enter the lane
		double counterSN=0;
		double counterEW=0;
		double counterWE=0;
		
		String ret = "";
		Block b;
		//double rndVal;
		int i;
		//int k = 0;
		for(i=0;i<totalTicks;i++) {						//so we loop through the total time we want 
			((Traffic)NS.get(span-1)).addTicks();		//we want the traffic light changing by the time, refer to addTicks method in Traffic class
			((Traffic)SN.get(span-1)).addTicks();
			((Traffic)EW.get(span-1)).addTicks();
			((Traffic)WE.get(span-1)).addTicks();
			
			for(int l=0;l<4;l++) {								//we will loop four times
				ArrayList<Block>lane = lanes.get(l);
				for (int m= lane.size() - 2; m >= 0; m--) {		//now this is for checking whether there is a car at next block, for checking this we need to check from the end of the lane to the start of the lane
					b = lane.get(m);
					if(b.getType()==BlockType.BLOCK_INTERSECT) {	//here we get to intersection
						if(((Intersection)b).turning())				//if the turning method is true, it will turn to the neighbor block which we defined earlier
						{
							((Intersection)b).getNeighbor().setAuto(b.getAuto());	//move the auto to the turning neighbor block
							b.setAuto(null);										//since we move the vehicle, we need to give space to the next vehicle, therefore we set the current position to null
						}
						else if(b.moveForward()) {								//if the turning method is not true, we will move forward will not turning
							b.getNext().setAuto(b.getAuto());					//go straight to the next block
							b.setAuto(null);									//set current position to null
						}
					}
					else if(b.moveForward())									//if the blocktype is not intersection, will go straight
					{
						b.getNext().setAuto(b.getAuto());
						b.setAuto(null);
					}
				}
			}
			
			for (int n= 0; n < 4; n++) {		//now we loop four times because there are four lanes in totl
				b = lanes.get(n).get(2*span+1);		//2*span+1 is the total blocks it has count from 0, we want the last block now
				if(b.getAuto()!=null) {				//if the last blockis not null, there is vehicle, so we can record the exit time
					b.getAuto().setExitTime(i);			//we will record exit time
					b.getAuto().setExitLane(n);			//we will record the lane that it exit
					if(n == 0) {
						counterNS++;					//if n=0, NS lane increase one car
					}
					else if(n == 1) {
						counterSN++;					//if n=1, SN lane increase one car
					}
					else if(n == 2) {
						counterEW++;					//if n=1, SN lane increase one car
					}
					else if(n == 3) {
						counterWE++;					//if n=1, SN lane increase one car
					}
					veh.add(b.getAuto());				//we record the car exit
					b.setAuto(null);					//after they exit, we set the last block to null that following car can come
				}
			}
			
			spawnCars(i);								//spawn cars, this is a method we explain before
			
			if(veh.size() > 0)							//if the total number of cars greater than 0
			{
				double sum = 0;							//we create a sum variable 
				for(int t=0;t<veh.size();t++) {
					sum+=veh.get(t).getExitTime() - veh.get(t).getEntryTime();		//now we calculate every cars' time from entering the lane until exit the lane
				}
				sum = sum / veh.size();				//then, divide by the total number of cars we will know average wait time
				ret += "Average wait time: "+sum + "\n";
				
				ret += "Total flow rate: "+ (veh.size()/(i + 0.0))+ "\n";
				ret += "Flow rate of NS: "+(counterNS / i)+ "\n";			//calculate the flow rate of each lane
				ret += "Flow rate of SN: "+(counterSN / i)+ "\n";
				ret += "Flow rate of EW: "+(counterEW / i)+ "\n";
				ret += "Flow rate of WE: "+(counterWE / i)+ "\n";
			}
			
		}
		for(int u=0;u<veh.size();u++) {
			ret+=veh.get(u).toString() + "\n";		//print out what we have here
		}
		
		
		return ret;
	}
}

		
	
