package Client;
import Traffic.RoadNetwork.*;
import java.util.*;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileWriter;
/**
 * This is the main class, and we instruct users what to enter and finally we get users input passed to all classes that we have, and using printWriter to make output file
 * @author junfan
 *
 */
public class main {
	public static void main(String [] args) {
		
		Intersection IS = new Intersection();
		Traffic T = new Traffic(2,2,5,14,0);
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter a number between 0 and 1 for entry rate: ");
		double input = scan.nextDouble();
		
		System.out.println("Please enter a number between 0 and 1 for turn rate: ");
		double input2 = scan.nextDouble();
		IS.setTurn(input2);
		//rn.setTurnRate(turnRate);
		
		System.out.println("Please set a duration for green light: ");
		int input3 = scan.nextInt();
		System.out.println("Please set a duration for orange light: ");
		int input6 = scan.nextInt();
		T.setGDuration(input3);
		T.setODuration(input6);
		
		
		System.out.println("Please enter how many ticks you want to simulate: ");
		int input4 = scan.nextInt();
		
		System.out.println("Please enter the span of the lanes: ");
		int input5 = scan.nextInt();

		RoadNetwork rn = new RoadNetwork(input5, input3, input6, input, input4, input2);
		System.out.println(rn.run());
		String output = rn.run();
		try {
			File ofile = new File("out.txt");
			PrintWriter pw = new PrintWriter(ofile);
			pw.print(output);
			pw.close();
		}catch(FileNotFoundException fnfe) {
			System.out.println("Unable to find out.txt");
		}
		
	}
}	


