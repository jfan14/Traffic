package Traffic.RoadNetwork;
import Traffic.RoadNetwork.Block;
/**
 * Here this class inherit {@link Block} class
 * @author junfan
 *
 */
public class Normal extends Block{
	public Normal(int t, int no) {
		super(t,no);
	}
	public Normal() {
		
	}
	/**
	 * This is the method determine it will move or stay at the current position
	 */
	public boolean moveForward() {
		if(this.getNext().getAuto() == null) {//Check whether next block is empty or occupied 
			return true;//return true can move forward
		}else {
			return false;//return false stay at current position
		}
				
	}
}
