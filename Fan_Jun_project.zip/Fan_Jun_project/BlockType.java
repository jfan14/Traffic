package Traffic.RoadNetwork;
/**
 * this is the enum class called BlockType, it has three element normal block, intersection block and traffic block
 * @author junfan
 *
 */
public enum BlockType{BLOCK_NORMAL, BLOCK_INTERSECT, BLOCK_TRAFFIC};	//Enum method of block type