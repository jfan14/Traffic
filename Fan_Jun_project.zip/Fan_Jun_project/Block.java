package Traffic.RoadNetwork;//change as needed
import Traffic.RoadNetwork.BlockType;
import Traffic.RoadNetwork.Auto;
/**
 * This is the super class {@link Block} that the attribute can be inherited by its child classes {@link Normal} {@link Intersection} and {@link Traffic}, it has {@link BlockType} that
 * has three kinds of blocks as the same names as classes above and {@link Auto} attribute for vehicles
 * 
 * @author junfan
 * @since 11.28, 2018
 */
public abstract class Block{		
		private BlockType type; //0:normal,1:intersection,2:traffic-light
		private int BlockNo;
		private Auto vehicle; // object of the vehicle occupying the block
		private Block Next; // the next block on the lane
		private Block Prev; // previous block on the lane
		private boolean ProcessedFlag;//flag for indicate whether the block has been processed during current tick of the simulation
		public Block() {
			
		}
		public Block(int t, int no){
			this.setType(t);
			this.setBlockNo(no);
		}
		public BlockType getType(){
			return this.type;
		}
		public void setType(int t){
			if(t==0) {
				this.type=BlockType.BLOCK_NORMAL;//if type is 0 will be normal block
			}else if(t==1) {
				this.type=BlockType.BLOCK_INTERSECT;//if type is 1 will be intersection block
			}else if(t==2){
				this.type=BlockType.BLOCK_TRAFFIC;//if type is 2 will be traffic block
			}
		}
		public int getBlockNo(){
			return this.BlockNo;		
		}
		public void setBlockNo(int posNo){
			this.BlockNo=posNo;             
		}
		public Auto getAuto(){
			return this.vehicle;
		}
		public void setAuto(Auto v){
			this.vehicle=v;
		}
		public Block getNext(){									//setters and getters
			return this.Next;
		}
		public void setNext(Block nextBlock){
			this.Next=nextBlock;			
		}
		public Block getPrev(){
			return this.Prev;							//not really use previous
		}
		public void setPrev(Block prevBlock){
			this.Prev=prevBlock;			
		}
		/*public int getBlockNo(){
			return this.BlockNo;			
		}
		public void setBlockNo(int no){
			this.BlockNo=no;
		}*/
		//public abstract void SetNeighbhors(Block[] neighhors);//Initialization to set the road network
		public abstract boolean moveForward();//method to move the vehicle to the next place in the road
}