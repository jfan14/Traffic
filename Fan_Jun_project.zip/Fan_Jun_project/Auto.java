package Traffic.RoadNetwork;
/**
 * This is the Auto class, and it is very important in roadnetwork class, entry time and exit time for calculating the average wait time, entry lane and exit lane for calculating the flow rate of each lane
 * and we give each car a ID, easy to to track
 * @author junfan
 *
 */
public class Auto {
	private int entryTime;	//enter time will be use in network class
	private int exitTime;	//enter time will be use in network class
	private String entryLane;	//the lane cars enter 
	private String exitLane;	//the lane cars leave
	private int ID;				//give a id for each car
	private static int uniqueID=0;
	private Block block;		//blcok variable
	
	public Auto() {		//constructor
		entryTime=0;
		entryTime=0;
		uniqueID++;
		ID = uniqueID;
	}
	
	public Auto(int new_entryTime, int new_exitTime) {
		this.entryTime = new_entryTime;
		this.exitTime = new_exitTime;
		uniqueID++;
		ID = uniqueID;
	}
	//setters and getters
	public int getEntryTime() {
		return this.entryTime;
	}
	
	public void setEntryTime(int entryTime) {
		this.entryTime = entryTime;
	}
	
	public int getExitTime() {
		return this.exitTime;
	}
	
	public void setExitTime(int exitTime) {
		this.exitTime = exitTime;
	}
	
	public Block getBlock() {
		return this.block;
	}
	
	public void setBlock(Block block) {
		this.block = block;
	}
	
	public String getEntryLane() {
		return this.entryLane;
	}
	/**
	 * At here because I use number representing lane therefore I need to convert back to the lane like NS, SN, EW, WE
	 * @param entryLane
	 */
	public void setEntryLane(int entryLane) {
		if(entryLane == 0)
		{
			this.entryLane = "NS";		//it is easy to use int variable to represent a lane then we define what number refer to which lane
		}
		else if(entryLane == 1)
		{
			this.entryLane = "SN";
		}
		else if(entryLane == 2)
		{
			this.entryLane = "EW";
		}else if(entryLane == 3) {
			this.entryLane = "WE";
		}
		
	}
	
	public String getExitLane() {
		return this.exitLane;			
	}
	/**
	 * This is pretty much like what we do above
	 * @param exitLane
	 */
	public void setExitLane(int exitLane) {
		if(exitLane == 0)
		{
			this.exitLane = "NS";			//same as above
		}
		else if(exitLane == 1)
		{
			this.exitLane = "SN";
		}
		else if(exitLane == 2)
		{
			this.exitLane = "EW";
		}else if(exitLane == 3) {
			this.exitLane = "WE";
		}
	}
	//toString method
	
	public String toString() {
		String ret;
		ret = "VehicleID: "+ ID + " EntryTime: " + this.entryTime + " Exit Time: " + this.exitTime + " Entry lane: "+this.getEntryLane() + " Exit lane: "+this.getExitLane();
		return ret;
	}
}
