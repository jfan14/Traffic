package Traffic.RoadNetwork;
import Traffic.RoadNetwork.Block;
import Client.main;
/**
 * This is the Traffic also inherit {@link Block} class with will add ticks for the traffic light and count each car move by 1 tick, and we get instruction from users in class {@link main} how many ticks 
 * for green light and orange light respectively
 * @author junfan
 *
 */
public class Traffic extends Block{
	private int ticks = 0;
	private int color;//0:Green, 1:Orange, 2:Red//
	private int gDuration;
	private int oDuration;
	
	public Traffic(){
		super();
		this.color=0;
		this.gDuration =0;
		this.oDuration =0;
	}
																		//constructor
	public Traffic(int t, int no, int new_gDuration, int new_oDuration, int new_color) {
		super(t, no);
		this.setColor(new_color);
		this.setGDuration(new_gDuration);
		this.setODuration(new_oDuration);
	}
	
	public int getTicks() {
		return this.ticks;
	}
	
	public void setTicks(int ticks) {
		this.ticks = ticks;
	}
	public int getGDuration() {
		return this.gDuration;
	}
	
	public void setGDuration(int gDuration) {
		this.gDuration = gDuration;
	}
	
	public int getODuration() {
		return this.oDuration;
	}
	
	public void setODuration(int oDuration) {
		
	}
	/**
	 * This is our class add ticks as mention above, essential to control the traffic light and cars' moving
	 */
	public void addTicks () {//adding ticks
		this.ticks++;
		if(this.ticks == gDuration && color == 0)//if the tick number is equal to duration number we defined and the color right now is green
		{
			this.setColor(1);//Means the ticks for green is end, we will switch it to orange
			setTicks(0);//reset the tick to 0
		}
		else if(this.ticks == oDuration && color == 1)//if the ticks for the orange end
		{
			this.setColor(2);//switch to red
			setTicks(0);//reset the tick to 0
		}
		else if(this.ticks == gDuration+oDuration && color == 2)//if the tick for the orange end
		{
			this.setColor(0);//switch color back to green
			setTicks(0);//reset the tick to 0
		}
	}
	
	public int getColor() {
		return this.color;
	}
	
	public void setColor(int color) {
		if(color == 0 || color ==1 || color == 2)//there are three kinds of color only 
			this.color = color;
		else
			System.out.println("Invalid light");
	}
	
	
	/*public static int RndGen(int input) {
		int rndVal = (int)(Math.random()*2+0);
		return rndVal;
	}*/
	/**
	 * This is the moveforward method of {@link Traffic} class, which will according to the light to determine whether cars can move or not
	 */
	public boolean moveForward() {
		if(this.getNext().getAuto() == null && this.getColor() != 2) {//pretty much similar to what we did in normal class
			return true;
		}else {
			return false;
		}
			
			
	}

}
